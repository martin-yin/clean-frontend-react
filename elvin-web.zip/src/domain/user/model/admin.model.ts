export interface AdminModel {
  email: string
  nick_name: string
  user_name: string
}
