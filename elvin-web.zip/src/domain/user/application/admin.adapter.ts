import { InjectFactorys } from '../../../code/decorator'
import { AdminLoginUseCase } from '../usecase/admin.login.use.case'

export const adminAdapter = () => {
  // Todo: 设计一个依赖注入
  const [adminLogin] = InjectFactorys([AdminLoginUseCase])

  const handleSubmit = async (form: any) => {
    const data = await adminLogin.execute(form)
    console.log(data)
  }

  const handleRegister = async (form: any) => {}
  return { handleSubmit, handleRegister }
}
