import { UseCase } from '../../../code/base/use.case'
import { RegisterParam } from '../model/admin.entity'
import { AdminModel } from '../model/admin.model'
import { AdminWebRepository } from '../repositories/admin.web.repository'

export class AdminRegisterUseCase implements UseCase<RegisterParam, AdminModel> {
  constructor(private adminRepository: AdminWebRepository) {}
  async execute(params: RegisterParam): Promise<AdminModel> {
    return await this.adminRepository.register(params)
  }
}
